Ext.define('Sky.view.product.BasketGrid', {
extend: 'Ext.grid.Panel',
    xtype: 'basketgrid',
 	itemId: 'basketGrid',
    bind: {
        store: '{basketproducts}',
    },
    hidePaging: true,
    disableCopy: true,
    title: 'Basket',

	columns: [
	
	{
        flex: 4,
        sortable: false,
        dataIndex: 'product',

    }]
});



