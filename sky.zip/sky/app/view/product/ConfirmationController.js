Ext.define('Sky.view.product.ConfirmationController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.confirmation',

	onclick: function() {
        var me = this
		
		var win = Ext.WindowManager.getActive();
		if (win) {
			win.close();
		}
    }
});