Ext.define('Sky.view.product.Product', {
    extend: 'Ext.window.Window',
	xtype: 'product',
    alias: 'widget.product',
    requires: [
        'Sky.view.product.ProductController',
		'Sky.view.product.ProductModel',
		'Sky.view.product.SportsGrid',
		'Sky.view.product.NewsGrid',
		'Sky.view.product.BasketGrid'
    ],
    controller: 'product',
	viewModel: {
        type: 'product'
    },
    bodyPadding: 5,
    closable: false,
    autoShow: true,
	width:1900,
	height: 400,
	draggable: false,
	layout: { 
		type: 'hbox',
		align: 'stretch',
		padding: 5,
		//margin: '10 200 200 10'

	},
	items: [{
        flex: 1,
        xtype: 'sportsgrid',
		itemId: 'sportsGrid',
		padding: 30,
		},
		{
        flex: 1,
        xtype: 'newsgrid',
		itemId: 'newsGrid',
		padding: 30,		
		},
		{                    
        flex: 1,
		padding: 30,
		layout: { 
			type: 'vbox',
			align: 'stretch',
	    },
			items: [{
			flex:3,
			xtype: 'basketgrid',
			itemId: 'basketGrid'       
			},{
			flex :1 ,
			xtype: 'button',
			text: 'Checkout',
			scale: 'medium',
			listeners: {
				click: 'onclick'
			}
		}]
	}]		
 });
   

