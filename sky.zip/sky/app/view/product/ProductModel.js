Ext.define('Sky.view.product.ProductModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.product',
    requires: [
        'Sky.store.product.Sports'
    ],
    stores: {
        sportsproducts: {
            type: 'sports'
        },
        newsproducts: {
            type: 'sports'
        },
		basketproducts: {
            type: 'sports'
        }
    }
});