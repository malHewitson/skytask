Ext.define('Sky.view.product.NewsGrid', {
extend: 'Ext.grid.Panel',
    xtype: 'newsgrid',
   gridConfig: {
		  multiSelect: true,
   } ,
 	itemId: 'newsGrid',
    bind: {
        store: '{newsproducts}',
    },
    hidePaging: true,
    disableCopy: true,
    title: 'News',

	columns: [
			{ 
		xtype: 'checkcolumn',
		dataIndex: 'isEnabled',
		flex: 1,
		listeners: {
			checkchange: 'onNewsChange'
		}
	},
	{
        flex: 3,
        sortable: false,
        dataIndex: 'product',

    }]
});



