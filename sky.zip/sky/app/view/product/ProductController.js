Ext.define('Sky.view.product.ProductController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.product',

	 init: function () {
        this.productResults = {
            sports: [],
            news: [],
			location: null
        };
		
        this.loadLocation();
    },
	loadLocation: function () {
        var me = this;
		var customerId = Ext.util.Cookies.get('customerID');
        me.productResults.sports = [];
        me.productResults.news = [];

		var url = '/sky-services/location/'+customerId
		 
        Ext.Ajax.request({
		
            url: url,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            success: function (response) {
                var location = Ext.JSON.decode(response.responseText).location;
				me.productResults.location = location
                me.loadProducts();
            },
            failure: function(response, opts) {
                console.log ("HTTP status failure - location= " + response.status);
				Ext.Msg.show({
					title:'Error',
					msg: 'Service call #1 failure. Response code = ' + response.status + ' - contact administration',
					icon: Ext.Msg.ERROR,
					buttons: Ext.Msg.OK
				});
            }
        });
    },
	loadProducts: function () {
        var me = this;

		var url = '/sky-services/product/'+me.productResults.location
 		 
        Ext.Ajax.request({
		
            url: url,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            success: function (response) {
                var products = Ext.JSON.decode(response.responseText).results;
				Ext.Array.each(products, function (products) {
					var category = products.category;
					if (category == 'Sports') {
						me.productResults.sports.push( products);
					}	
					else {	
						me.productResults.news.push( products);
					}
				})
                me.setGrids();
            },
            failure: function(response, opts) {
                console.log ("HTTP status failure - products= " + response.status);
				Ext.Msg.show({
					title:'Error',
					msg: 'Service call #2 failure. Response code = ' + response.status + ' - contact administration',
					icon: Ext.Msg.ERROR,
					buttons: Ext.Msg.OK
				});

            }
        });
    },
	setGrids: function () {
        var me = this;
		
        var sports = me.getViewModel().getStore('sportsproducts'),
            news = me.getViewModel().getStore('newsproducts'),
			basketStore = me.getViewModel().getStore('basketproducts')
			;

        sports.loadRawData(me.productResults.sports);
		news.loadRawData(me.productResults.news);
		basketStore.loadRawData([])

    },
	onSportsChange: function () {
        var me = this
		me.maintainBasket()
        
    },
	onNewsChange: function () {
        var me = this
		me.maintainBasket()
        
    },	
	maintainBasket: function () {
        var me = this
	    var sportStoreItems = me.getViewModel().getStore('sportsproducts').getData().items;
		var newStoreItems = me.getViewModel().getStore('newsproducts').getData().items;
		var basketStore = me.getViewModel().getStore('basketproducts');
	
		productsEnabled = []
		Ext.Array.each(sportStoreItems, function (record) {
			if (record.data.isEnabled == true )
			{
				productsEnabled.push(record)
			}
        });	
		Ext.Array.each(newStoreItems, function (record) {
			if (record.data.isEnabled == true )
			{
				productsEnabled.push(record)
			}
        });	
		basketStore.loadRawData(productsEnabled)		
	},
	
	onclick: function () {
	    var me = this
	    var customerId = Ext.util.Cookies.get('customerID');
		var basketStore = me.getViewModel().getStore('basketproducts').getData().items;
		if (basketStore.length == 0  ) {
             Ext.Msg.confirm('Checkout', 'No products have been selected, are you sure?', 'checkout', this);
		}
		else {
			me.checkout('yes')
		}
    },

    checkout: function (choice) {

        if (choice === 'yes') {
			var me = this
	        var customerId = Ext.util.Cookies.get('customerID');
		    var basketStore = me.getViewModel().getStore('basketproducts').getData().items;
            var productsSelected = new String();
		    Ext.Array.each(basketStore, function (record) {
    			productsSelected = productsSelected.concat(productsSelected.length?", ":"").concat(record.data.product)

            });	
		    productsSelected = productsSelected.replace(/,\s([^,]+)$/, ' and $1')

            this.getView().destroy();
  
			this.confirmationWindow = Ext.create('Sky.view.product.Confirmation', {
                       productDetails : { customerId: customerId, productsSelected: productsSelected } 
                    
				   });
			this.confirmationWindow.show();			
        }
    }

});