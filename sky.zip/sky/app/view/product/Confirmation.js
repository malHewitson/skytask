Ext.define('Sky.view.product.Confirmation', {
    extend: 'Ext.window.Window',
    xtype: 'confirmation',
    alias: 'widget.confirmation',
    requires: [
    	'Sky.view.product.ConfirmationController'
    ],
    controller: 'confirmation',
    bodyPadding: 5,
    title: 'Confirmation',
    closable: false,
    autoShow: true,
	draggable: false,
	width:600,
	
	initComponent: function() {
		var me = this;
	    me.items = me.buildItems();
        me.callParent();
	},
	buildItems: function() {

		var customerId = this.productDetails.customerId
		var productsSelected = this.productDetails.productsSelected
 		
        return [
            {
				 xtype: 'textfield',
				 flex :1,
                 fieldLabel: 'CustomerId:',
                 readOnly: true,
                 value: customerId                      
             },
			 { 
			    flex :4,
                fieldLabel      : 'Products Selected', 
                value            : productsSelected, 
                id              : 'txtareafield',
                xtype           : 'textarea', 
                allowBlank      : false, 
     
			},	
			{                    
				flex: 1,
				layout: { 
					type: 'vbox',
					align: 'center',
				},
			    items: [
				{
					flex :1 ,
					xtype: 'button',
					text: 'Close',
					scale: 'medium',
					listeners: {
						click: 'onclick'
					}
			    }]	
			}
        ];
    }
 });
   

