Ext.define('Sky.view.product.SportsGrid', {
extend: 'Ext.grid.Panel',

    xtype: 'sportsgrid',
    gridConfig: {
 		  multiSelect: true,
    } ,
 	itemId: 'sportsGrid',
    bind: {
        store: '{sportsproducts}'
    },
    hidePaging: true,
    disableCopy: true,
    title: 'Sports',

	columns: [
			{ 
		xtype: 'checkcolumn',
		dataIndex: 'isEnabled',
        flex: 1,
		listeners: {
			checkchange: 'onSportsChange'
		}
	},
	{
        flex: 3,
       sortable: false,
        dataIndex: 'product',

    }]
});



