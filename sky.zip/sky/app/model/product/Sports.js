Ext.define('Sky.model.product.Sports', {
    extend: 'Ext.data.Model',
	fields: [
		{name: 'product', type: 'string'},
		{name: 'category', type: 'string'},
        {name: 'location', type: 'string'},
		{name: 'isEnabled', type: 'boolean'},
	]
});

