Ext.define('Sky.store.product.Sports', {
    extend: 'Ext.data.Store',
	requires: [
        'Sky.model.product.Sports'
    ],
    model: 'Sky.model.product.Sports',
    alias: 'store.sports',
   

	listeners: { 
		exception: function(proxy, response, operation){
    		console.log('exception');
		},
		load: function(){
    		console.log('loaded');
    	}
	}
    
});