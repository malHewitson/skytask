package com.sky.task

import org.springframework.context.annotation.Import

@Import([Application])
class PersistenceTestApplication {
}
