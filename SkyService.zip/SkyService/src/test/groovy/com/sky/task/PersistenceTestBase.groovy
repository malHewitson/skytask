package com.sky.task

/**
 * Created by mhewitson on 5/22/2016.
 */
import com.sky.task.repository.ProductRepository
import org.junit.Before
import org.junit.runner.RunWith
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.SpringApplicationConfiguration
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner
import org.springframework.test.context.transaction.TransactionConfiguration
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.transaction.annotation.Transactional

import javax.persistence.EntityManager

@RunWith(SpringJUnit4ClassRunner)
@SpringApplicationConfiguration(classes = PersistenceTestApplication)
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
@WebAppConfiguration
abstract class PersistenceTestBase {
    @Autowired
    ProductRepository productRepository

    @Autowired
    EntityManager entityManager

    @Before
    void beforePersistenceTestBase() {

        productRepository.deleteAll()
        entityManager.flush()
        entityManager.clear()
    }
}
