package com.sky.task
import com.sky.task.repository.ProductRepository
import org.junit.Before
import org.junit.runner.RunWith
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.IntegrationTest
import org.springframework.boot.test.SpringApplicationConfiguration
import org.springframework.boot.test.TestRestTemplate
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner
import org.springframework.test.context.transaction.TransactionConfiguration
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.client.RestTemplate

import javax.persistence.EntityManager

@WebAppConfiguration
@IntegrationTest(["server.port:0", "management.port:0"])
@RunWith(SpringJUnit4ClassRunner)
@SpringApplicationConfiguration(classes = Application)
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
abstract class IntegrationTestBase {

    RestTemplate template = new TestRestTemplate()

    def baseUrl

    @Value('${local.server.port}')
    int port

    Set<String> roles = []
    String orgUUID = UUID.randomUUID()

    @Autowired
    ProductRepository productRepository

    @Autowired
    EntityManager entityManager

    @Before
    void beforeIntegrationTestBase() {
        baseUrl = "http://localhost:$port/sky-services"

        productRepository.deleteAll()
        entityManager.flush()
        entityManager.clear()
    }

 }
