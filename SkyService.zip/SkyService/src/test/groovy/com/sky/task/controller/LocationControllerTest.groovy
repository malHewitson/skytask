package com.sky.task.controller
import com.sky.task.BaseSkyServiceTest
import com.sky.task.dto.LocationResponse
import com.sky.task.service.CustomerLocationService

class LocationControllerTest extends BaseSkyServiceTest {

    LocationController controller


    def setup() {
        controller = new LocationController()
        controller.customerLocationService =  Mock(CustomerLocationService)

    }


    def "test get location LONDON"() {
        setup:
        controller.customerLocationService.getLocation(_) >> new LocationResponse( location : "LONDON" )
        when:
        LocationResponse response = controller.getLocationId("1001")

        then:
        assert response.location == "LONDON"

    }


    def "test get location LIVERPOOL"() {
        setup:
        controller.customerLocationService.getLocation(_) >> new LocationResponse( location : "LIVERPOOL" )
        when:
        LocationResponse response =  controller.getLocationId("1002")

        then:
        assert response.location == "LIVERPOOL"

    }


}