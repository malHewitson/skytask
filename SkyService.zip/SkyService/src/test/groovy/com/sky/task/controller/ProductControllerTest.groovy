package com.sky.task.controller
import com.sky.task.BaseSkyServiceTest
import com.sky.task.dto.Product
import com.sky.task.dto.ProductResponse
import com.sky.task.service.CatalogueService

class ProductControllerTest extends BaseSkyServiceTest{

    ProductController controller


    def setup() {
        controller = new ProductController()
        controller.catalogueService =  Mock(CatalogueService)

    }

    def "test get test location "() {
        setup:
        Product product1 = newProduct("Test Product1")

        controller.catalogueService.getProducts(_) >> new ProductResponse( results : [product1] )
        when:
        ProductResponse response = controller.getProducts("Test Location")

        then:
        assert response.results.size() == 1
        assert response.results.get(0).product == "Test Product1"

    }

    def "test get invalid test location "() {
        setup:

        controller.catalogueService.getProducts(_) >> new ProductResponse( results : [] )
        when:
        ProductResponse response = controller.getProducts("Test Location")

        then:
        assert response.results.size() == 0


    }

    def "test get test location multiple results"() {
        setup:
        Product product1 = newProduct("Test Product1")
        Product product2 = newProduct("Test Product2")
        Product product3 = newProduct("Test Product3")

        controller.catalogueService.getProducts(_) >> new ProductResponse( results : [product1, product2, product3] )

        when:

        ProductResponse response = controller.getProducts("Test Location")

        then:
        assert response.results.size() == 3
        assert response.results.get(0).product == "Test Product1"
        assert response.results.get(1).product == "Test Product2"
        assert response.results.get(2).product == "Test Product3"
    }


}
