package com.sky.task.repository

import com.sky.task.PersistenceTestBase
import com.sky.task.model.ProductEntity
import org.junit.Test


class ProductRepositoryTest extends PersistenceTestBase {
    @Test
    void readOneProductWithLocation() {
        ProductEntity expected = newProductEntity("test product1")

        productRepository.save(expected)
        entityManager.flush()
        entityManager.clear()

        List<ProductEntity> actual = productRepository.findByLocationOrLocationIsNull(expected.location)
        assert actual.size() == 1
        assert expected == actual.get(0)
    }

    @Test
    void readOneProductWithNoLocation() {
        ProductEntity expected = newProductEntityNoLocation("test product2")

        productRepository.save(expected)
        entityManager.flush()
        entityManager.clear()

        List<ProductEntity> actual = productRepository.findByLocationOrLocationIsNull(expected.location)
        assert actual.size() == 1
        assert expected == actual.get(0)
    }

    @Test
    void readTwoProductsWithNoLocation() {
        ProductEntity expected1 = newProductEntity("test product1")
        productRepository.save(expected1)
        ProductEntity expected2 = newProductEntity("test product2")
        productRepository.save(expected2)
        entityManager.flush()
        entityManager.clear()

        List<ProductEntity> actual = productRepository.findByLocationOrLocationIsNull(expected1.location)
        assert actual.size() == 2
        assert expected1 == actual.get(0)
        assert expected2 == actual.get(1)

    }

    @Test
    void readProductsWithLocation() {
        ProductEntity expected1 = newProductEntity("test product1")
        productRepository.save(expected1)
        ProductEntity expected2 = newProductEntity("test product2")
        productRepository.save(expected2)
        entityManager.flush()
        entityManager.clear()

        List<ProductEntity> actual = productRepository.findByLocationOrLocationIsNull(expected1.location)
        assert actual.size() == 2
        assert expected1 == actual.get(0)
        assert expected2 == actual.get(1)

    }

    @Test
    void readMixofProductsWithandWithoutLocation() {
        ProductEntity expected1 = newProductEntity("test product1")
        productRepository.save(expected1)
        ProductEntity expected2 = newProductEntity("test product2")
        productRepository.save(expected2)
        ProductEntity expected3 = newProductEntityNoLocation("test product3")
        productRepository.save(expected3)
        entityManager.flush()
        entityManager.clear()

        List<ProductEntity> actual = productRepository.findByLocationOrLocationIsNull(expected1.location)
        assert actual.size() == 3
        assert expected1 == actual.get(0)
        assert expected2 == actual.get(1)
        assert expected3 == actual.get(2)
    }

    @Test
    void readAlwaysFindProductsWithNoLocation() {
        ProductEntity expected1 = newProductEntity("test product1")
        productRepository.save(expected1)
        ProductEntity expected2 = newProductEntity("test product2")
        productRepository.save(expected2)
        ProductEntity expected3 = newProductEntityNoLocation("test product3")
        productRepository.save(expected3)
        entityManager.flush()
        entityManager.clear()

        List<ProductEntity> actual = productRepository.findByLocationOrLocationIsNull("not used")
        assert actual.size() == 1
       assert expected3 == actual.get(0)
    }

    @Test
    void readNoProductsForLocation() {
        ProductEntity expected1 = newProductEntity("test product1")
        productRepository.save(expected1)
        ProductEntity expected2 = newProductEntity("test product2")
        productRepository.save(expected2)

        entityManager.flush()
        entityManager.clear()

        List<ProductEntity> actual = productRepository.findByLocationOrLocationIsNull("not used")
        assert actual.size() == 0

    }

    public static ProductEntity newProductEntity(String product) {
        ProductEntity productEntity = new ProductEntity()
        productEntity.location = "TestLocation"
        productEntity.category = "Sport"
        productEntity.product = product
        productEntity
    }

    public static ProductEntity newProductEntityNoLocation(String product) {
        ProductEntity productEntity = new ProductEntity()
        productEntity.category = "Sport"
        productEntity.product = product
        productEntity
    }
}
