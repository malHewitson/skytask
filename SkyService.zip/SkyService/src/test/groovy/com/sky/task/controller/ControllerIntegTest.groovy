package com.sky.task.controller
import com.sky.task.IntegrationTestBase
import com.sky.task.dto.LocationResponse
import org.junit.Test
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity

class ControllerIntegTest extends IntegrationTestBase{

    @Test
    public void testGetLocationLONDON() {


        LocationResponse expected = new LocationResponse(location: "LONDON")

        HttpEntity<String> entity = new HttpEntity<String>()
        ResponseEntity<LocationResponse> responseEntity = template.exchange("$baseUrl/location/1001",
                                    HttpMethod.GET, entity, LocationResponse)

        assert responseEntity.statusCode == HttpStatus.OK
        assert responseEntity.body.location == expected.location

    }

    @Test
    public void testGetInvalidLocation() {

        HttpEntity<String> entity = new HttpEntity<String>()
        ResponseEntity<LocationResponse> responseEntity = template.exchange("$baseUrl/location/1003",
                HttpMethod.GET, entity, LocationResponse)

        assert responseEntity.statusCode == HttpStatus.BAD_REQUEST
    }

}


