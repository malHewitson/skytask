package com.sky.task.service
import com.sky.task.BaseSkyServiceTest
import com.sky.task.dto.ProductResponse
import com.sky.task.model.ProductEntity
import com.sky.task.repository.ProductRepository
import com.sky.task.repository.ProductRepositoryTest

class CatalogueServiceImplTest  extends BaseSkyServiceTest{

    CatalogueServiceImpl service


    def setup() {
        service = new CatalogueServiceImpl()
        service.productRepository =  Mock(ProductRepository)

    }

    def "test get test product "() {
        setup:
        ProductEntity productEntity1 = ProductRepositoryTest.newProductEntity("Test Product1")

        service.productRepository.findByLocationOrLocationIsNull(_) >> [productEntity1]
        when:
        ProductResponse response = service.getProducts("TestLocation")

        then:
        assert response.results.size() == 1
        assert response.results.get(0).product == "Test Product1"

    }

    def "test get product with invalid test location "() {
        setup:

        service.productRepository.findByLocationOrLocationIsNull(_) >> []
        when:
        ProductResponse response = service.getProducts("TestLocation")

        then:
        assert response.results.size() == 0


    }

    def "test get test product with multiple results"() {
        setup:
        ProductEntity productEntity1 = ProductRepositoryTest.newProductEntity("Test Product1")
        ProductEntity productEntity2 = ProductRepositoryTest.newProductEntity("Test Product2")
        ProductEntity productEntity3 = ProductRepositoryTest.newProductEntity("Test Product3")

        service.productRepository.findByLocationOrLocationIsNull(_) >> [productEntity1, productEntity2, productEntity3]
        when:
        ProductResponse response = service.getProducts("TestLocation")

        then:
        assert response.results.size() == 3
        assert response.results.get(0).product == "Test Product1"
        assert response.results.get(1).product == "Test Product2"
        assert response.results.get(2).product == "Test Product3"
    }


}
