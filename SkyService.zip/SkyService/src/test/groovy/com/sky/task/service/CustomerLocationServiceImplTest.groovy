package com.sky.task.service
import com.sky.task.BaseSkyServiceTest
import com.sky.task.dto.LocationResponse
import com.sky.task.exception.LocationException

class CustomerLocationServiceImplTest extends BaseSkyServiceTest {
    CustomerLocationServiceImpl service

    def setup() {
        service = new CustomerLocationServiceImpl()
    }

    def "test get location LONDON"() {
        setup:

        when:
        LocationResponse response = service.getLocation("1001")

        then:
        assert response.location == "LONDON"

    }


    def "test get location LIVERPOOL"() {
        setup:

        when:
        LocationResponse response = service.getLocation("1002")

        then:
        assert response.location == "LIVERPOOL"

    }

    def "test get location for unknown user"() {
        setup:

        when:
        LocationResponse response = service.getLocation("1003")

        then:
        thrown LocationException

    }
}