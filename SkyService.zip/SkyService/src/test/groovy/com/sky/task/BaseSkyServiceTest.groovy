package com.sky.task
import com.sky.task.dto.Product
import spock.lang.Specification

class BaseSkyServiceTest extends Specification {


    public static Product newProduct(String aProduct) {
        Product product = new Product()
        product.location = "test location"
        product.category = "Sport"
        product.product = aProduct
        product
    }

    public static Product newProductNoLocation(String aProduct) {
        Product product = new Product()
        product.category = "Sport"
        product.product = aProduct
        product
    }
}
