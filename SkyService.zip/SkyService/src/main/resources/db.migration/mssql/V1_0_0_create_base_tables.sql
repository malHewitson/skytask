CREATE TABLE dbo.product(
	id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  product varchar(40) NOT NULL,
  category varchar(40) NOT NULL,
    location varchar(40) NULL,
  CONSTRAINT product_unq UNIQUE (product)
)
GO