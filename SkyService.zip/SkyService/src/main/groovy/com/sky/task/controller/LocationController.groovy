package com.sky.task.controller

import com.sky.task.dto.LocationResponse
import com.sky.task.service.CustomerLocationService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/location")
class LocationController {

        @Autowired
        CustomerLocationService customerLocationService

        @RequestMapping(value = '/{customerId}', method = RequestMethod.GET, produces="application/json")
        public LocationResponse getLocationId(@PathVariable String customerId) {
                return customerLocationService.getLocation(customerId)
        }

}
