package com.sky.task.exception

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ResponseStatus



@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Location request parameters were invalid.")
public class LocationException extends RuntimeException {
    private static final long serialVersionUID = -2312982364439105240L;

    public LocationException(String reason) {
        super(reason)
    }
}

