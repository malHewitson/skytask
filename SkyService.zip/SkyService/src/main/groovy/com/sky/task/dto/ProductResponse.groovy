package com.sky.task.dto
import com.fasterxml.jackson.annotation.JsonIgnoreProperties


@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductResponse {
    List<Product> results = []
    List<Product> getResults() {
        return results
    }
    void setResults(List<Product> results) {
        this.results = results
    }

}
