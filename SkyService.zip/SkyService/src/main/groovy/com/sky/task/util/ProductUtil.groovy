package com.sky.task.util

import com.sky.task.dto.Product
import com.sky.task.model.ProductEntity

public class ProductUtil {


    static Product fromEntity(ProductEntity entity) {
        Product product = new Product(

                product: entity.product,
                category: entity.category,
                location: entity.location?entity.location:'ALL'

        )

        return product
    }


}