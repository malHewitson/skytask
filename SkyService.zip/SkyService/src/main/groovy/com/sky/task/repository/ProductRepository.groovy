package com.sky.task.repository
import com.sky.task.model.ProductEntity
import org.springframework.data.repository.CrudRepository

interface ProductRepository extends CrudRepository<ProductEntity, Integer> {
    List<ProductEntity> findByLocation(String locationId)

    List<ProductEntity> findByLocationOrLocationIsNull(String locationId)


}