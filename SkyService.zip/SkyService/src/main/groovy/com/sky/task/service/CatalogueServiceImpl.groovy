package com.sky.task.service
import com.sky.task.dto.Product
import com.sky.task.dto.ProductResponse
import com.sky.task.model.ProductEntity
import com.sky.task.repository.ProductRepository
import com.sky.task.util.ProductUtil
import groovy.transform.CompileStatic
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
@CompileStatic
class CatalogueServiceImpl implements CatalogueService {

    @Autowired
    ProductRepository productRepository



    @Override
    public ProductResponse getProducts(String locationId) {

        List<ProductEntity> product = productRepository.findByLocationOrLocationIsNull(locationId)
        List<Product> results = []
        product.each() { entity ->
            results.add(ProductUtil.fromEntity(entity))
        }
        ProductResponse response = new ProductResponse(results: results)
        response

    }
}
