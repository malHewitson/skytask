package com.sky.task.service

import com.sky.task.dto.LocationResponse
import com.sky.task.exception.LocationException
import groovy.transform.CompileStatic
import org.springframework.stereotype.Service

@Service
@CompileStatic
class CustomerLocationServiceImpl implements CustomerLocationService {

    @Override
    public LocationResponse getLocation(String customerId) {
        String location
        switch (customerId) {
            case "1001" :
                location = "LONDON"
                break
            case "1002" :
                location = "LIVERPOOL"
                break
            default :
                throw new LocationException ("Invalid Customer Id {"+customerId + "}" )

        }

        LocationResponse response = new LocationResponse(location: location)
        response
    }
}

