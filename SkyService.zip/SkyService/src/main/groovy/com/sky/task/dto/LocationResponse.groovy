package com.sky.task.dto
import com.fasterxml.jackson.annotation.JsonIgnoreProperties

@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationResponse {

    private String location;

    String getLocation() {
        return location
    }

    void setLocation(String location) {
        this.location = location
    }
}
