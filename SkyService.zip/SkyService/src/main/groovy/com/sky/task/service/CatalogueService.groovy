package com.sky.task.service

import com.sky.task.dto.ProductResponse

interface CatalogueService {

    //List<Product> getProducts(String locationId)
    ProductResponse getProducts(String locationId)
}