package com.sky.task.service

import com.sky.task.dto.LocationResponse

interface CustomerLocationService {
    LocationResponse getLocation(String customerId)
}
