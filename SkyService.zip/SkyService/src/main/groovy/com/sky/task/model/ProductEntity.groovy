package com.sky.task.model

import groovy.transform.EqualsAndHashCode
import javax.persistence.Table
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id


@Entity
@EqualsAndHashCode(excludes = "id")
@Table(name='product')
public class ProductEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Integer id

    @Column
    String product
    @Column
    String category
    @Column
    String location

}