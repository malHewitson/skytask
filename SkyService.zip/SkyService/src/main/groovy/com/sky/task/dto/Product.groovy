package com.sky.task.dto
import com.fasterxml.jackson.annotation.JsonIgnoreProperties


@JsonIgnoreProperties(ignoreUnknown = true)
public class Product {

    private String product;
    private String category;
    private String location;

    String getProduct() {
        return product
    }

    void setProduct(String product) {
        this.product = product
    }

    String getLocation() {
        return location
    }

    void setLocation(String location) {
        this.location = location
    }

    String getCategory() {
        return category
    }

    void setCategory(String category) {
        this.category = category
    }

}
